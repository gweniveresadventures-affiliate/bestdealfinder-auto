
# BestDealFinder Auto (Full Repo)

This repository contains two sites and an automated workflow to update product lists daily and auto-deploy:

- `site_static/` - Static HTML site (BestDealFinder). The script regenerates HTML pages here.
- `site_nextjs/` - Next.js starter site (BestDealHub). The script updates pages in `site_nextjs/pages/`.
- `data/products.json` - Source product lists (contains affiliate-tagged search URLs using tag discoverqua04-20).
- `scripts/updateProducts.js` - Node script that regenerates static pages and Next.js page files.
- `.github/workflows/daily-update.yml` - Schedules the update daily at 08:00 UTC and runs on-demand via workflow_dispatch.

How to use (quick):
1. Create or open a GitHub repo (e.g., bestdealfinder-auto) and upload these files (commit to main).
2. On GitHub -> Actions -> select "Daily update products" and click Run workflow once.
3. On Netlify: Import from GitHub and set publish directory to `site_static`.
4. On Vercel: Import the `site_nextjs` project and deploy (Next.js auto-detects).

To trigger an immediate update, go to the Actions tab -> choose "Daily update products" -> Run workflow -> select branch.
