
// scripts/updateProducts.js
const fs = require('fs');
const path = require('path');
function shuffle(a){ for(let i=a.length-1;i>0;i--){ const j=Math.floor(Math.random()*(i+1)); [a[i],a[j]]=[a[j],a[i]] } return a }
const repoRoot = path.resolve(__dirname, '..');
const dataPath = path.join(repoRoot, 'data', 'products.json');
if (!fs.existsSync(dataPath)) { console.error('Missing data/products.json'); process.exit(1); }
const products = JSON.parse(fs.readFileSync(dataPath,'utf8'));
const dailyDeals = [];
Object.keys(products).forEach(cat=>{ products[cat] = shuffle(products[cat]); dailyDeals.push(Object.assign({category:cat}, products[cat][0])); });
const staticDir = path.join(repoRoot, 'site_static');
if(!fs.existsSync(staticDir)) fs.mkdirSync(staticDir, { recursive: true });
function makeCategoryHtml(cat, items){
  const title = `${cat.charAt(0).toUpperCase()+cat.slice(1)} Picks - BestDealFinder`;
  const ol = items.map(i=>`<li><a href="${i.url}" target="_blank" rel="noopener noreferrer">${i.name}</a></li>`).join('\\n');
  return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${title}</title></head><body style="font-family:Arial,Helvetica,sans-serif;margin:20px;background:#f7fafc;color:#0f172a"><a href="index.html">← Home</a><h1>${title}</h1><ol>${ol}</ol><p style="font-size:12px;color:#6b7280">Disclosure: This page contains Amazon affiliate links.</p></body></html>`;
}
Object.keys(products).forEach(cat=>{ const html = makeCategoryHtml(cat, products[cat]); fs.writeFileSync(path.join(staticDir, `${cat}.html`), html, 'utf8'); });
let topList = []; Object.keys(products).forEach(cat=> topList = topList.concat(products[cat]));
const topHtml = '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Top Picks - BestDealFinder</title></head><body style="font-family:Arial,Helvetica,sans-serif;margin:20px;background:#f7fafc;color:#0f172a"><a href="index.html">← Home</a><h1>Top Picks</h1><ol>' + topList.map(i=>`<li>${i.name} — <a href="${i.url}" target="_blank">Buy on Amazon</a></li>`).join('\\n') + '</ol><footer><p>© '+ new Date().getFullYear() +' BestDealFinder — Affiliate links included.</p></footer></body></html>';
fs.writeFileSync(path.join(staticDir, 'top100.html'), topHtml, 'utf8');
const indexHtml = `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>BestDealFinder</title></head><body style="font-family:Arial,Helvetica,sans-serif;margin:20px;background:#f7fafc;color:#0f172a"><header><h1>BestDealFinder</h1><p>Quick access to top Amazon deals. Affiliate links included.</p></header><nav><a href="kitchen.html">Kitchen</a> | <a href="tech.html">Tech</a> | <a href="beauty.html">Beauty</a> | <a href="fitness.html">Fitness</a> | <a href="pets.html">Pets</a> | <a href="top100.html">Top 100</a></nav><main><section><h2>Daily Deals</h2><ul>${dailyDeals.map(d=>`<li>${d.category}: <a href="${d.url}" target="_blank">${d.name}</a></li>`).join('')}</ul></section></main><footer><p>© ${new Date().getFullYear()} BestDealFinder — Affiliate links included.</p></footer></body></html>`;
fs.writeFileSync(path.join(staticDir,'index.html'), indexHtml, 'utf8');
const nextDir = path.join(repoRoot, 'site_nextjs','pages');
if (fs.existsSync(nextDir)) {
  Object.keys(products).forEach(cat=>{
    const lines = [`<h1>${cat.charAt(0).toUpperCase()+cat.slice(1)} Picks</h1>`,`<ol>`];
    products[cat].forEach(i=> lines.push(`<li><a href="${i.url}" target="_blank" rel="noopener noreferrer">${i.name}</a></li>`));
    lines.push(`</ol>`);
    lines.push(`<p class='disclosure'>Disclosure: This page contains Amazon affiliate links.</p>`);
    const content = "export default function Page(){ const html = `"+lines.join('')+"`; return <div className='container' dangerouslySetInnerHTML={{__html: html}} /> }";
    fs.writeFileSync(path.join(nextDir, `${cat}.js`), content, 'utf8');
  });
  const nextTop = "export default function Top100(){ const html = `"+ topList.map(i=>`<li>${i.name} — <a href=\\\"${i.url}\\\" target=\\\"_blank\\\">Buy on Amazon</a></li>`).join('') +"`; return <div className='container' dangerouslySetInnerHTML={{__html: `<h1>Top Picks</h1><ol>"+ topList.map(i=>`<li>${i.name} — <a href=\\\"${i.url}\\\" target=\\\"_blank\\\">Buy on Amazon</a></li>`).join('') +"</ol>`}} /> }";
  fs.writeFileSync(path.join(nextDir,'top100.js'), nextTop, 'utf8');
}
console.log('Products updated and static/next pages regenerated.');
